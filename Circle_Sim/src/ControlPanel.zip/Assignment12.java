// Assignment #: 12
//         Name: Kevin Cabrera
//    StudentID: 1204185783
//      Lecture: MW 1030-1145
//  Description: The Assignment 12 class creates a controlpanel and
//               adds it as its Applet content and also sets its size.
import javax.swing.*;
import java.awt.*;

import javax.swing.Timer;
import java.awt.event.*;
import javax.swing.event.*;

public class Assignment12 extends JApplet  {
  private final int WIDTH = 450;
  private final int HEIGHT = 300;

  public void init()
   {
       ControlPanel panel = new ControlPanel(WIDTH,HEIGHT);
       getContentPane().add(panel);
       setSize(WIDTH,HEIGHT);
   }
 }
